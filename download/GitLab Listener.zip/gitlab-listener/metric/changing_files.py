def compute_cf(changes):
    return len(changes['changes'])
