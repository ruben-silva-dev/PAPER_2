def compute_pn(gl_merge_request):
    return len(gl_merge_request.participants())
