def compute_rn(gl_commits):
    return len(gl_commits)
